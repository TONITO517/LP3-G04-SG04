package proyecto;


public class Main {
public static void main(String[] args) {
   System.out.println("SISTEMA DE CÁLCULO DE ENVÍOS");
   System.out.println("===============================\n");
   
   CalculadoraEnvio calculadora = new CalculadoraEnvio();
   
   double peso = 5.0; 
   double distancia = 100.0; 
   
   System.out.println("Paquete: " + peso + "kg, Distancia: " + distancia + "km\n");
   
   System.out.println("1. ENVÍO ECONÓMICO:");
   calculadora.setMetodo(new EnvioEconomico());
   calculadora.mostrarCosto(peso, distancia);
   
   System.out.println("\n2. ENVÍO EXPRESS:");
   calculadora.setMetodo(new EnvioExpress());
   calculadora.mostrarCosto(peso, distancia);
   
   System.out.println("\n3. ENVÍO PRIORITARIO:");
   calculadora.setMetodo(new EnvioPrioritario());
   calculadora.mostrarCosto(peso, distancia);
   
   System.out.println("\n Sistema finalizado");
}
}