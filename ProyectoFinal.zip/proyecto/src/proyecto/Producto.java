package proyecto;

import java.util.*;

interface MetodoEnvio {
 double calcularCosto(double peso, double distancia);
 int getTiempoEntrega();
}

class EnvioEconomico implements MetodoEnvio {
 public double calcularCosto(double peso, double distancia) {
     return (peso * 0.5) + (distancia * 0.1);
 }
 public int getTiempoEntrega() { return 7; }
}

class EnvioExpress implements MetodoEnvio {
 public double calcularCosto(double peso, double distancia) {
     return (peso * 1.5) + (distancia * 0.3);
 }
 public int getTiempoEntrega() { return 2; }
}

class EnvioPrioritario implements MetodoEnvio {
 public double calcularCosto(double peso, double distancia) {
     return (peso * 2.0) + (distancia * 0.5) + 10;
 }
 public int getTiempoEntrega() { return 1; }
}

class CalculadoraEnvio {
 private MetodoEnvio metodo;
 
 public void setMetodo(MetodoEnvio metodo) {
     this.metodo = metodo;
 }
 
 public void mostrarCosto(double peso, double distancia) {
     if (metodo == null) {
         System.out.println("Seleccione un método de envío primero");
         return;
     }
     double costo = metodo.calcularCosto(peso, distancia);
     int tiempo = metodo.getTiempoEntrega();
     System.out.printf("Costo: $%.2f | Tiempo: %d días\n", costo, tiempo);
 }
}

