package Actividades;

import javax.swing.*;
import javax.sound.sampled.*;
import java.awt.*;
import java.io.IOException;
import java.io.InputStream;
public class Ejercicio4 extends JFrame {
    private Clip clip;
    private long posicionPausa = 0;
    public Ejercicio4() {
        setTitle("Reproductor de Música");
        setSize(400, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());
        JButton btnReproducir = new JButton("Reproducir");
        JButton btnPausar = new JButton("Pausar");
        JButton btnReanudar = new JButton("Reanudar");
        btnReproducir.addActionListener(e -> reproducirDesdeInicio());
        btnPausar.addActionListener(e -> pausar());
        btnReanudar.addActionListener(e -> reanudar());
        add(btnReproducir);
        add(btnPausar);
        add(btnReanudar);

        cargarAudio("tropical.wav");
    }
    private void cargarAudio(String nombreArchivo) {
        try {
            InputStream audioSrc = getClass().getResourceAsStream(nombreArchivo);
            if (audioSrc == null) {
                JOptionPane.showMessageDialog(this, "No se encontró el archivo: " + nombreArchivo);
                return;
            }

            InputStream bufferedIn = new java.io.BufferedInputStream(audioSrc);
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(bufferedIn);
            clip = AudioSystem.getClip();
            clip.open(audioStream);
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException ex) {
            JOptionPane.showMessageDialog(this, "Error al cargar el audio: " + ex.getMessage());
        }
    }
    private void reproducirDesdeInicio() {
        if (clip != null) {
            clip.stop();
            clip.setMicrosecondPosition(0);
            clip.start();
        }
    }
    private void pausar() {
        if (clip != null && clip.isRunning()) {
            posicionPausa = clip.getMicrosecondPosition();
            clip.stop();
        }
    }
    private void reanudar() {
        if (clip != null && !clip.isRunning()) {
            clip.setMicrosecondPosition(posicionPausa);
            clip.start();
        }
    }
}
