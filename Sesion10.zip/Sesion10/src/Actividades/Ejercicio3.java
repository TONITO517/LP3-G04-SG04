package Actividades;
import javax.swing.*;
import javax.sound.sampled.*;
import java.awt.*;
import java.io.IOException;
import java.io.InputStream;
public class Ejercicio3 extends JFrame {
    public Ejercicio3() {
        setTitle("Reproductor de Efectos de Sonido");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(1, 3, 10, 10));
        JButton btnPiano = new JButton("Piano");
        JButton btnTropical = new JButton("Tropical");
        JButton btnAlarma = new JButton("Alarma");
        btnPiano.addActionListener(e -> reproducirSonido("piano.wav"));
        btnTropical.addActionListener(e -> reproducirSonido("tropical.wav"));
        btnAlarma.addActionListener(e -> reproducirSonido("alarma.wav"));
        add(btnPiano);
        add(btnTropical);
        add(btnAlarma);
    }
    private void reproducirSonido(String nombreArchivo) {
        try {
            InputStream audioSrc = getClass().getResourceAsStream(nombreArchivo);
            if (audioSrc == null) {
                JOptionPane.showMessageDialog(this, "No se encontró el archivo: " + nombreArchivo);
                return;
            }
            InputStream bufferedIn = new java.io.BufferedInputStream(audioSrc);
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(bufferedIn);
            Clip clip = AudioSystem.getClip();
            clip.open(audioStream);
            clip.start();
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException ex) {
            JOptionPane.showMessageDialog(this, "Error al reproducir el sonido: " + ex.getMessage());
        }
    }
}

