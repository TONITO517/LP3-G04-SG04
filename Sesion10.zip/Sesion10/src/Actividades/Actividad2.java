package Actividades;
import javax.swing.*;

public class Actividad2 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Duarte-Vega");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        
        AppGraficos2 panel = new AppGraficos2();
        frame.add(panel);
        
        frame.setVisible(true);
    }
}