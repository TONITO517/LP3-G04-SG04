package Actividades;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Ejercicio1main extends JFrame {
    private Ejercicio1 producto;
    public Ejercicio1main() {
        super("Gestión de Producto");
        producto = new Ejercicio1("Sin nombre", 0.0, 0, "Sin categoría");
        JTextField txtNombre = new JTextField(15);
        JTextField txtPrecio = new JTextField(15);
        JTextField txtStock = new JTextField(15);
        JTextField txtCategoria = new JTextField(15);
        JButton btnActualizar = new JButton("Actualizar Producto");
        JLabel lblMostrar = new JLabel(producto.toString());
        setLayout(new GridLayout(6, 2, 10, 10));
        add(new JLabel("Nombre:")); add(txtNombre);
        add(new JLabel("Precio:")); add(txtPrecio);
        add(new JLabel("Cantidad Stock:")); add(txtStock);
        add(new JLabel("Categoría:")); add(txtCategoria);
        add(btnActualizar);
        add(lblMostrar);
        btnActualizar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    producto.setNombre(txtNombre.getText());
                    producto.setPrecio(Double.parseDouble(txtPrecio.getText()));
                    producto.setCantidadStock(Integer.parseInt(txtStock.getText()));
                    producto.setCategoria(txtCategoria.getText());

                    lblMostrar.setText(producto.toString());
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null,
                            "Error en los datos ingresados",
                            "ERROR",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        setSize(400, 280);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
    public static void main(String[] args) {
        new Ejercicio1main();
    }
}
