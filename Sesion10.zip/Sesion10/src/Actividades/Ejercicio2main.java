package Actividades;

import javax.swing.SwingUtilities;

public class Ejercicio2main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new Ejercicio2().setVisible(true);
        });
    }
}

