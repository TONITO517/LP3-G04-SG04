package Actividades;
import javax.swing.*;
import java.awt.*;

public class AppGraficos2 extends JPanel {
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.BLUE);
        g.drawLine(10, 10, 100, 100);
        g.setColor(Color.RED);
        g.drawRect(50, 50, 100, 50);
        g.setColor(Color.GREEN);
        g.drawOval(150, 50, 100, 50);
        g.setColor(Color.ORANGE);
        g.fillOval(200, 150, 50, 50);
        g.setColor(Color.BLACK);
        g.drawString("Ejemplo graficos", 10, 200);
    }
}