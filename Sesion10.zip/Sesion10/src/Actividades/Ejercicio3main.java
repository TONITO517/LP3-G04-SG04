package Actividades;

import javax.swing.SwingUtilities;

public class Ejercicio3main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new Ejercicio3().setVisible(true);
        });
    }
}
