package Actividades;

import javax.swing.*;
import java.awt.*;

public class Ejercicio2 extends JFrame {
    private JTextField[] camposTemperatura = new JTextField[7];
    private String[] dias = {"Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"};
    private int[] temperaturas = new int[7];
    private JPanel panelGrafico;
    public Ejercicio2() {
        setTitle("Registro de Temperaturas Semanales");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        JPanel panelEntrada = new JPanel(new GridLayout(8, 2, 5, 5));
        for (int i = 0; i < 7; i++) {
            panelEntrada.add(new JLabel(dias[i] + ":"));
            camposTemperatura[i] = new JTextField();
            panelEntrada.add(camposTemperatura[i]);
        }
        JButton btnMostrar = new JButton("Mostrar Gráfico");
        panelEntrada.add(btnMostrar);
        add(panelEntrada, BorderLayout.WEST);
        panelGrafico = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                dibujarGrafico(g);
            }
        };
        add(panelGrafico, BorderLayout.CENTER);
        btnMostrar.addActionListener(e -> {
            for (int i = 0; i < 7; i++) {
                try {
                    temperaturas[i] = Integer.parseInt(camposTemperatura[i].getText());
                } catch (NumberFormatException ex) {
                    temperaturas[i] = 0; 
                }
            }
            panelGrafico.repaint();
        });
    }
    private void dibujarGrafico(Graphics g) {
        int ancho = panelGrafico.getWidth();
        int alto = panelGrafico.getHeight();
        int margen = 50;
        int espacioX = (ancho - 2 * margen) / 6; 
        int maxTemp = 50; 
        g.drawLine(margen, alto - margen, ancho - margen, alto - margen); 
        g.drawLine(margen, margen, margen, alto - margen); 
        int[] puntosX = new int[7];
        int[] puntosY = new int[7];
        for (int i = 0; i < 7; i++) {
            puntosX[i] = margen + i * espacioX;
            puntosY[i] = alto - margen - (temperaturas[i] * (alto - 2 * margen) / maxTemp);
            g.fillOval(puntosX[i] - 5, puntosY[i] - 5, 10, 10);
            g.drawString(dias[i], puntosX[i] - 15, alto - margen + 20);
        }
        g.setColor(Color.BLUE);
        for (int i = 0; i < 6; i++) {
            g.drawLine(puntosX[i], puntosY[i], puntosX[i + 1], puntosY[i + 1]);
        }
    }
}
