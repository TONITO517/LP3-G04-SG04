package Actividades;

import javax.swing.SwingUtilities;

public class Ejercicio4main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new Ejercicio4().setVisible(true);
        });
    }
}

