/**
 * 
 */
/**
 * 
 */
module Actividades{
	requires java.desktop;
	requires javafx.media;
	requires javafx.graphics;
}